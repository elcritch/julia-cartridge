x="println(\"x=\$(repr(x))\\n\$x\")"
println("x=$(repr(x))\n$x")
